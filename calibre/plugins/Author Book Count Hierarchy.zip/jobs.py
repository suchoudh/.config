# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals
__license__   = 'GPL v3'
__copyright__ = '2014,2015,2016,2017,2018,2019 DaltonST <DaltonShiTzu@outlook.com>'
__my_version__ = "1.2.2"   #  Technical changes after Python 3.8 testing with Calibre 4.99.2

from calibre.gui2.threaded_jobs import ThreadedJob
from calibre.utils.logging import Log

from polyglot.queue import Queue

from calibre_plugins.author_book_count_hierarchy.main import Create_ABC_Hierarchy

def start_abc_hierarchy_threaded(self, my_gui, my_guidb, callback):
    self.gui = my_gui
    job = ThreadedJob('author book count hierarchy plugin','Author Book Count Hierarchy',Create_ABC_Hierarchy,(self, my_guidb), {}, callback)
    self.gui.job_manager.run_threaded_job(job)
    self.gui.status_bar.show_message(_('This ABCH job will update every book in your library'), 5000)
#END of jobs.py
